# 使用说明

## 所需环境

```
docker
docker-compose
```

## 修改配置

```
修改conf 文件夹下的所有文件
设置的是管理员用户名、管理员密码、数据库用户名、密码 数据库名称
```

## 启动

```
docker-compose up -d
```

## 修改配置

启动成功后停止
```
修改文件./nextcloud/config/config.php

第三行增加配置：
'default_language' => 'zh_CN',

找到行“ 0 => 'localhost',”
在其下新增一行 1 => 'ip地址/域名',
```